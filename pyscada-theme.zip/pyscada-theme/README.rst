PyScada Theme Extension
=======================

This is a extension for PyScada to add a view theme.


What is Working
---------------

 - nothing is test


What is not Working/Missing
---------------------------

 - Documentation

 Installation
 ------------

  - pip install https://github.com/clavay/PyScada-Theme/tarball/master

Contribute
----------

 - Issue Tracker: https://github.com/clavay/PyScada-Theme/issues
 - Source Code: https://github.com/clavay/PyScada-Theme

 - Format code before sending a pull request :
  - python code using `black <https://black.readthedocs.io>`_
  - django template, JavaScript and CSS using `DjHTML <https://github.com/rtts/djhtml>`_


License
-------

The project is licensed under the _GNU AFFERO GENERAL PUBLIC LICENSE Version 3 (AGPLv3)_.
-
